package com.company;

import java.util.*;

public class Model {

    ArrayList<Vector3f> vertices;
    ArrayList<Vector2f> textureVertices;
    ArrayList<Vector3f> normals;

    public Model() {
        vertices = new ArrayList<Vector3f>();
        textureVertices = new ArrayList<Vector2f>();
        normals = new ArrayList<Vector3f>();
        polygonVertexIndices = new ArrayList<ArrayList<Integer>>();
        polygonTextureVertexIndices = new ArrayList<ArrayList<Integer>>();
        polygonNormalIndices = new ArrayList<ArrayList<Integer>>();
    }

    // Каждый контейнер - список полигонов, где полигон описывается индексами вершин, текстурных вершин или нормалей.
    // Индексов для полигона может быть 3 (треугольник) и более.
    ArrayList<ArrayList<Integer>> polygonVertexIndices;
    ArrayList<ArrayList<Integer>> polygonTextureVertexIndices;
    ArrayList<ArrayList<Integer>> polygonNormalIndices;
}
