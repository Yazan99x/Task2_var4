package com.company;

// В будущем эти классы будут реализовывать общий интерфейс. Это тема следующих занятий.
public class Vector2f {
    public Vector2f(float x, float y) {
        this.x = x;
        this.y = y;
    }

    float x, y;
}
