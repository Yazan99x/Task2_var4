package com.company;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Main {

    public static void main(String[] args) throws IOException {

        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\deleteFaces.txt");
        String deleteFileContent = deleteFileName.toString();

        Model model = ObjReader.read(fileContent);
        DeleteFace.deleteFace(model, deleteFileContent, fileName, true);
        System.out.println("All good! :)");
    }
}
