package com.company;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;

class ObjReaderTest {

    @Test
    public void testDeleteFaces() throws IOException {
        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\deleteFaces.txt");
        String deleteFileContent = deleteFileName.toString();
        Model model = ObjReader.read(fileContent);
        int size1 = model.polygonVertexIndices.size();
        int size2 = model.polygonTextureVertexIndices.size();
        int size3 = model.polygonNormalIndices.size();
        DeleteFace.deleteFace(model, deleteFileContent, fileName, true);
        if (model.polygonVertexIndices.size() == size1 && model.polygonTextureVertexIndices.size() == size2
                && model.polygonNormalIndices.size() == size3) {
            throw new AssertionError("Тест провален, ни один полигон не удалился");
        }
    }

    @Test
    public void testNotDeletePolygons() throws IOException {
        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\testNotDelete.txt");
        String deleteFileContent = deleteFileName.toString();
        Model model = ObjReader.read(fileContent);
        int size1 = model.polygonVertexIndices.size();
        int size2 = model.polygonTextureVertexIndices.size();
        int size3 = model.polygonNormalIndices.size();
        DeleteFace.deleteFace(model, deleteFileContent, fileName, true);
        if (model.polygonVertexIndices.size() != size1
                && model.polygonTextureVertexIndices.size() != size2 && model.polygonNormalIndices.size() != size3) {
            throw new AssertionError("Некоторые полигоны удалены");
        }
    }

    @Test
    public void testDeleteAllPolygons() throws IOException {
        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\testDelete.txt");
        String deleteFileContent = deleteFileName.toString();
        Model model = ObjReader.read(fileContent);
        DeleteFace.deleteFace(model, deleteFileContent, fileName, true);
        if (model.polygonVertexIndices.size() != 0
                && model.polygonTextureVertexIndices.size() != 0 && model.polygonNormalIndices.size() != 0) {
            throw new AssertionError("Тест провален, удалены не все полигоны");
        }
    }

    @Test
    public void testNotDeleteVertexes() throws IOException {
        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\deleteFaces.txt");
        String deleteFileContent = deleteFileName.toString();
        Model model = ObjReader.read(fileContent);
        int size1 = model.vertices.size();
        int size2 = model.textureVertices.size();
        int size3 = model.normals.size();
        DeleteFace.deleteFace(model, deleteFileContent, fileName, false);
        if (model.vertices.size() != size1 && model.textureVertices.size() != size2 && model.normals.size() != size3) {
            throw new AssertionError("Тест провален, одна (или несколько) вершин удалилсь");
        }
    }

    @Test
    public void testDeleteVertexes() throws IOException {
        Path fileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\taskText.obj");
        String fileContent = Files.readString(fileName);
        Path deleteFileName = Path.of("D:\\JavaTasks\\ObjReaderInitial\\ObjReaderInitial\\deleteFaces.txt");
        String deleteFileContent = deleteFileName.toString();
        Model model = ObjReader.read(fileContent);
        int size1 = model.vertices.size();
        int size2 = model.textureVertices.size();
        int size3 = model.normals.size();
        DeleteFace.deleteFace(model, deleteFileContent, fileName, true);
        if (model.vertices.size() == size1 && model.textureVertices.size() == size2 && model.normals.size() == size3) {
            throw new AssertionError("Тест провален, ни одна вершина не удалилась");
        }
    }

    @Test
    public void testParseVertex01() {
        ArrayList<String> wordsInLineWithoutToken = new ArrayList<>(Arrays.asList("1.01", "1.02", "1.03"));
        Vector3f result = ObjReader.parseVertex(wordsInLineWithoutToken, 5);
        Vector3f expectedResult = new Vector3f(1.01f, 1.02f, 1.03f);
        Assertions.assertTrue(result.equals(expectedResult));
    }

    @Test
    public void testParseVertex02() {
        ArrayList<String> wordsInLineWithoutToken = new ArrayList<>(Arrays.asList("1.01", "1.02", "1.03"));
        Vector3f result = ObjReader.parseVertex(wordsInLineWithoutToken, 5);
        Vector3f expectedResult = new Vector3f(1.01f, 1.02f, 1.10f);
        Assertions.assertFalse(result.equals(expectedResult));
    }

    @Test
    public void testParseVertex03() {
        ArrayList<String> wordsInLineWithoutToken = new ArrayList<>(Arrays.asList("ab", "o", "ba"));
        try {
            ObjReader.parseVertex(wordsInLineWithoutToken, 10);
        } catch (ObjReaderException exception) {
            String expectedError = "Error parsing OBJ file on line: 10. Failed to parse float value.";
            Assertions.assertEquals(expectedError, exception.getMessage());
        }
    }

    @Test
    public void testParseVertex04() {
        ArrayList<String> wordsInLineWithoutToken = new ArrayList<>(Arrays.asList("1.0", "2.0"));
        try {
            ObjReader.parseVertex(wordsInLineWithoutToken, 10);
        } catch (ObjReaderException exception) {
            String expectedError = "Error parsing OBJ file on line: 10. Too few vertex arguments.";
            Assertions.assertEquals(expectedError, exception.getMessage());
        }
    }

    @Test
    public void testParseVertex05() {
        // АГААА! Вот тест, который говорит, что у метода нет проверки на более, чем 3 числа
        // А такой случай лучше не игнорировать, а сообщать пользователю, что у него что-то не так
        // ассерт, чтобы не забыть про тест:
        Assertions.assertTrue(false);


        ArrayList<String> wordsInLineWithoutToken = new ArrayList<>(Arrays.asList("1.0", "2.0", "3.0", "4.0"));
        try {
            ObjReader.parseVertex(wordsInLineWithoutToken, 10);
        } catch (ObjReaderException exception) {
            String expectedError = "";
            Assertions.assertEquals(expectedError, exception.getMessage());
        }
    }
}